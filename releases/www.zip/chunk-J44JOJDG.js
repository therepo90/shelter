import{b as a,c as b}from"./chunk-M2X7KQLB.js";import"./chunk-2R6CW7ES.js";export{a as GESTURE_CONTROLLER,b as createGesture};
